
import 'package:flutter/material.dart';

void main() {
  runApp(const SmartTaskManager());
}

class SmartTaskManager extends StatelessWidget {
  const SmartTaskManager({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Task Manager',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const TaskHome(),
    );
  }
}

class TaskHome extends StatelessWidget {
  const TaskHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Smart Task Manager')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          TaskTile(title: 'Learn Flutter', completed: true),
          TaskTile(title: 'Build Portfolio Project', completed: false),
          TaskTile(title: 'Apply for Internship', completed: false),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: const Icon(Icons.add),
      ),
    );
  }
}

class TaskTile extends StatelessWidget {
  final String title;
  final bool completed;

  const TaskTile({super.key, required this.title, required this.completed});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(
          completed ? Icons.check_circle : Icons.circle_outlined,
          color: completed ? Colors.green : Colors.grey,
        ),
        title: Text(title),
      ),
    );
  }
}
