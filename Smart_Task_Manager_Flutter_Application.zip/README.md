
# Smart Task Manager – Flutter Application

## Description
A Flutter-based task management application that allows users
to manage daily tasks efficiently with a clean and modern UI.

## Features
- Task listing UI
- Material Design
- Clean and scalable structure
- Ready for CRUD & database integration
- Suitable for portfolio and internships

## Tech Stack
- Flutter
- Dart

## How to Run
1. Install Flutter SDK
2. Run `flutter pub get`
3. Run `flutter run`

## Future Enhancements
- Add local database (SQLite)
- Task reminders
- User authentication
